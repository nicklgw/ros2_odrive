#CAN配置
sudo slcand -o -c -s5 /dev/ttyACM0 can0  #s5代表250k bitrate
sudo ifconfig can0 up
sudo ifconfig can0 txqueuelen 1000

#odrivetool配置
#To save the configuration to a file on the PC, run:
odrivetool backup-config odrive_config.json
#To restore the configuration form such a file, run:
odrivetool restore-config odrive_config.json

dev0.axis0.config.can.node_id=0
dev0.axis0.config.can.node_id=1
dev0.can.config.baud_rate = 250000

colcon build
source install/setup.bash

ros2 launch odrive_botwheel_explorer botwheel_explorer.launch.py

ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args --params-file ./teleop.yaml

ros2 run twist_stamper twist_stamper --ros-args -r cmd_vel_in:=cmd_vel -r cmd_vel_out:=botwheel_explorer/cmd_vel
