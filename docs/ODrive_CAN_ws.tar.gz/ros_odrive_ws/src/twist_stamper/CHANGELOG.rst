^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package twist_stamper
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.3 (2022-09-16)
------------------
* fix python setuptools install error (`#1 <https://github.com/joshnewans/twist_stamper/issues/1>`_)
  Co-authored-by: Sönke Niemann <soenke.niemann@ipk.fraunhofer.de>
* Contributors: niemsoen

0.0.2 (2021-01-27)
------------------
* Add unstamper
* Removed cache files from git
* Switched license to Apache 2.0 to match ROS2 standard
* Fixed unit test issues.
* Fixed license
* Added content
* Initial commit
* Contributors: Josh Newans
